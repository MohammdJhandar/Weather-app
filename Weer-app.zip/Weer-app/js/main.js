$(document).ready(function(){
  $('#submitWeather').click(function(){
  //get the input of the input field
    let city = $('#city').val();
  //if the input is not empty make the request
    if (city != ''){
      $.ajax({
          url: 'http://api.openweathermap.org/data/2.5/weather?q=' + city + "&units=metric" + "&APPID=5496fbbac1d973777bd3f052ca1a43e3",
          type: "GET",
          success: function(data) {
            let widget = show(data)
            $('#show').html(widget).hide().fadeIn(1000);
            $('#city').val('');
            $('#error').hide();
            console.log(data);
          }
      });
  //else the input is empty and show an alert message
    }else {
      $('#error').html("<div class='alert alert-danger' id='errorCity'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>Field cannot be empty</div>");
    }
  })
});

function show(data) {
  return  "<h2>" + "Current Weather for " + data.name + " , " + data.sys.country + "</h2>" +
          "<h3>" + "<strong>Weather: </strong>" + data.weather[0].main + "</h3>" +
          "<h3>" + "<strong>Description: </strong> <img src='http://openweathermap.org/img/w/" + data.weather[0].icon + ".png'>" + data.weather[0].description + "</h3>" +
          "<h3>" + "<strong>Temperature: </strong>" + data.main.temp + "&deg;C" + "</h3>" +
          "<h3>" + "<strong>Huminity: </strong>" + data.main.humidity + " %" + "</h3>" +
          "<h3>" + "<strong>Min. Temperature: </strong>" + data.main.temp_min + "&deg;C" + "</h3>" +
          "<h3>" + "<strong>Max. Temperature: </strong>" + data.main.temp_max + "&deg;C" + "</h3>";
}
